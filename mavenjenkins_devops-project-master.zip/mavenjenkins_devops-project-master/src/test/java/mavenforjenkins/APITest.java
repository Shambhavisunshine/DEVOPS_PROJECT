package mavenforjenkins;

public class APITest {

	
	public void checkAPIResponse()
	{
		
	}
	
	
}
